#pragma once

#define HTTP_SERVER "207.180.196.125"
#define HTTP_PORT 80

#define TFTP_SERVER "207.180.196.125"
